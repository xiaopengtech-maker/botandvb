/**
 * index.js
 * MB Bank -> Telegram notifier PRO + Admin Panel
 * Node.js 18+
 */
const fs = require("fs");
const path = require("path");
const http = require("http");
const crypto = require("crypto");
const { URL } = require("url");

const ROOT = __dirname;
const CONFIG_FILE = path.join(ROOT, "config.json");
const STATE_FILE = path.join(ROOT, "seen.json");

const BOT_TOKEN = process.env.BOT_TOKEN || "YOUR_BOT_TOKEN";
const CHAT_ID = process.env.CHAT_ID || "-1000000000000";
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || "123456";
const PORT = Number(process.env.PORT || 3000);

const DEFAULT_CONFIG = {
  apis: [
    {
      name: "MB API 1",
      url: "https://thueapibank.com/historyapimbbank/529ac6b9fec7758cff3209ebd864e180",
      enabled: true
    }
  ],
  activeApiIndex: 0,
  checkIntervalMs: 4000,
  sendDelayMs: 1200,
  telegramRetry: 5,
  telegramRetryDelayMs: 1500,
  maxSeen: 5000,
  batchMode: true
};

let config = null;
let seenSet = new Set();
let seenList = [];
let firstRun = true;
let checking = false;
let queue = Promise.resolve();
let lastCheckAt = null;
let lastSuccessAt = null;
let totalSent = 0;
let totalErrors = 0;
let checkTimer = null;
const sessions = new Map();

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}
function nowISO() {
  return new Date().toISOString();
}
function esc(s = "") {
  return String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}
function formatMoney(x) {
  const n = Number(String(x || "0").replace(/[^\d.-]/g, ""));
  if (Number.isNaN(n)) return `${x} VND`;
  return n.toLocaleString("vi-VN") + " VND";
}
function trimText(s = "", max = 800) {
  s = String(s || "").trim();
  if (s.length <= max) return s;
  return s.slice(0, max - 3) + "...";
}
function getRefNo(tx) {
  return String(tx?.refNo || "").trim();
}
function normalizeTransactions(list) {
  if (!Array.isArray(list)) return [];
  return list.filter((tx) => tx && getRefNo(tx)).map((tx) => ({
    refNo: getRefNo(tx),
    accountNo: tx.accountNo || "",
    creditAmount: tx.creditAmount || "0",
    debitAmount: tx.debitAmount || "0",
    description: tx.description || "",
    transactionDate: tx.transactionDate || "",
    postingDate: tx.postingDate || "",
    currency: tx.currency || "VND",
    raw: tx
  }));
}
function safeNumber(value, fallback, min = 0, max = Number.MAX_SAFE_INTEGER) {
  const n = Number(value);
  if (!Number.isFinite(n)) return fallback;
  if (n < min) return min;
  if (n > max) return max;
  return n;
}
function ensureConfigShape(raw) {
  const merged = { ...DEFAULT_CONFIG, ...(raw || {}) };
  if (!Array.isArray(merged.apis) || !merged.apis.length) {
    merged.apis = JSON.parse(JSON.stringify(DEFAULT_CONFIG.apis));
  }
  merged.apis = merged.apis.map((x, i) => ({
    name: String(x?.name || `API ${i + 1}`),
    url: String(x?.url || "").trim(),
    enabled: x?.enabled !== false
  })).filter(x => x.url);
  if (!merged.apis.length) merged.apis = JSON.parse(JSON.stringify(DEFAULT_CONFIG.apis));
  merged.activeApiIndex = safeNumber(merged.activeApiIndex, 0, 0, Math.max(0, merged.apis.length - 1));
  merged.checkIntervalMs = safeNumber(merged.checkIntervalMs, DEFAULT_CONFIG.checkIntervalMs, 1000, 3600000);
  merged.sendDelayMs = safeNumber(merged.sendDelayMs, DEFAULT_CONFIG.sendDelayMs, 0, 60000);
  merged.telegramRetry = safeNumber(merged.telegramRetry, DEFAULT_CONFIG.telegramRetry, 1, 20);
  merged.telegramRetryDelayMs = safeNumber(merged.telegramRetryDelayMs, DEFAULT_CONFIG.telegramRetryDelayMs, 100, 60000);
  merged.maxSeen = safeNumber(merged.maxSeen, DEFAULT_CONFIG.maxSeen, 100, 100000);
  merged.batchMode = Boolean(merged.batchMode);
  return merged;
}

function loadConfig() {
  try {
    if (!fs.existsSync(CONFIG_FILE)) {
      config = ensureConfigShape(DEFAULT_CONFIG);
      saveConfig();
      return;
    }
    const raw = JSON.parse(fs.readFileSync(CONFIG_FILE, "utf8"));
    config = ensureConfigShape(raw);
    saveConfig();
  } catch (err) {
    console.log("[CONFIG] load error:", err.message);
    config = ensureConfigShape(DEFAULT_CONFIG);
    saveConfig();
  }
}
function saveConfig() {
  fs.writeFileSync(CONFIG_FILE, JSON.stringify(config, null, 2), "utf8");
}
function loadState() {
  try {
    if (!fs.existsSync(STATE_FILE)) {
      console.log("[STATE] chưa có seen.json");
      return;
    }
    const raw = fs.readFileSync(STATE_FILE, "utf8");
    const parsed = JSON.parse(raw);
    if (Array.isArray(parsed)) {
      seenList = parsed.filter(Boolean).map(String);
      seenSet = new Set(seenList);
      console.log(`[STATE] loaded ${seenList.length} ref`);
      return;
    }
    if (parsed && Array.isArray(parsed.refs)) {
      seenList = parsed.refs.filter(Boolean).map(String);
      seenSet = new Set(seenList);
      console.log(`[STATE] loaded ${seenList.length} ref`);
    }
  } catch (err) {
    console.log("[STATE] load error:", err.message);
  }
}
function saveState() {
  try {
    const payload = { refs: seenList, updatedAt: nowISO(), total: seenList.length };
    fs.writeFileSync(STATE_FILE, JSON.stringify(payload, null, 2), "utf8");
  } catch (err) {
    console.log("[STATE] save error:", err.message);
  }
}
function addSeen(refNo) {
  if (!refNo || seenSet.has(refNo)) return;
  seenSet.add(refNo);
  seenList.push(refNo);
  if (seenList.length > config.maxSeen) {
    const extra = seenList.length - config.maxSeen;
    const removed = seenList.splice(0, extra);
    for (const r of removed) seenSet.delete(r);
  }
}
function hasSeen(refNo) {
  return seenSet.has(refNo);
}
function getActiveApi() {
  return config.apis[config.activeApiIndex] || config.apis[0];
}

function buildSingleMessage(tx) {
  const amount = Number(tx.creditAmount || 0) > 0 ? formatMoney(tx.creditAmount)
    : Number(tx.debitAmount || 0) > 0 ? "-" + formatMoney(tx.debitAmount)
    : "0 VND";
  return [
    "💸 <b>Giao dịch mới</b>",
    "",
    `Tài Khoản : <code>${esc(tx.accountNo || "Không rõ")}</code>`,
    `Số Tiền : <b>${esc(amount)}</b>`,
    `Nội Dung : ${esc(trimText(tx.description || "Không có", 1200))}`,
    `Ngày Giờ : ${esc(tx.transactionDate || tx.postingDate || "Không rõ")}`,
    `Mã GD : <code>${esc(tx.refNo)}</code>`
  ].join("\n");
}
function buildBatchMessage(list) {
  const lines = [];
  lines.push(`💸 <b>Có ${list.length} giao dịch mới</b>`);
  lines.push("");
  list.forEach((tx, i) => {
    const amount = Number(tx.creditAmount || 0) > 0 ? formatMoney(tx.creditAmount)
      : Number(tx.debitAmount || 0) > 0 ? "-" + formatMoney(tx.debitAmount)
      : "0 VND";
    lines.push(`<b>${i + 1}.</b>`);
    lines.push(`Tài Khoản : <code>${esc(tx.accountNo || "Không rõ")}</code>`);
    lines.push(`Số Tiền : <b>${esc(amount)}</b>`);
    lines.push(`Nội Dung : ${esc(trimText(tx.description || "Không có", 500))}`);
    lines.push(`Ngày Giờ : ${esc(tx.transactionDate || tx.postingDate || "Không rõ")}`);
    lines.push(`Mã GD : <code>${esc(tx.refNo)}</code>`);
    lines.push("");
  });
  let msg = lines.join("\n");
  if (msg.length > 3900) msg = msg.slice(0, 3850) + "\n\n<i>... tin nhắn đã được rút gọn</i>";
  return msg;
}
async function sendTelegram(text) {
  const url = `https://api.telegram.org/bot${BOT_TOKEN}/sendMessage`;
  const res = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      chat_id: CHAT_ID,
      text,
      parse_mode: "HTML",
      disable_web_page_preview: true
    })
  });
  const data = await res.json().catch(() => null);
  if (!res.ok || !data || !data.ok) {
    const errMsg = data ? JSON.stringify(data) : `${res.status} ${res.statusText}`;
    throw new Error(`Telegram send failed: ${errMsg}`);
  }
  return data;
}
async function sendWithRetry(text) {
  let attempt = 0;
  let delay = config.telegramRetryDelayMs;
  while (attempt < config.telegramRetry) {
    try {
      attempt++;
      await sendTelegram(text);
      return true;
    } catch (err) {
      console.log(`[TG] attempt ${attempt}/${config.telegramRetry} failed: ${err.message}`);
      if (attempt >= config.telegramRetry) throw err;
      await sleep(delay);
      delay *= 2;
    }
  }
  return false;
}
function enqueue(taskFn) {
  queue = queue.then(() => taskFn()).catch((err) => {
    totalErrors++;
    console.log("[QUEUE] error:", err.message);
  });
  return queue;
}
async function processNotifications(newTxs) {
  if (!newTxs.length) return;
  newTxs = [...newTxs].reverse();
  if (config.batchMode && newTxs.length > 1) {
    await enqueue(async () => {
      const msg = buildBatchMessage(newTxs);
      await sendWithRetry(msg);
      totalSent += newTxs.length;
      console.log(`[SEND] batch sent ${newTxs.length} tx`);
      await sleep(config.sendDelayMs);
    });
    return;
  }
  for (const tx of newTxs) {
    await enqueue(async () => {
      const msg = buildSingleMessage(tx);
      await sendWithRetry(msg);
      totalSent++;
      console.log(`[SEND] sent ${tx.refNo}`);
      await sleep(config.sendDelayMs);
    });
  }
}
async function fetchTransactions() {
  const api = getActiveApi();
  if (!api?.url) throw new Error("Chưa có API đang dùng");
  const res = await fetch(api.url, {
    method: "GET",
    headers: {
      Accept: "application/json",
      "User-Agent": "Mozilla/5.0 MB-Telegram-Bot",
      "Cache-Control": "no-cache"
    }
  });
  if (!res.ok) throw new Error(`API ${res.status} ${res.statusText}`);
  const json = await res.json();
  if (!json || json.status !== "success" || !Array.isArray(json.TranList)) {
    throw new Error("API trả về sai định dạng");
  }
  return normalizeTransactions(json.TranList);
}
async function check() {
  if (checking) {
    console.log("[CHECK] skip vì đang check dở");
    return;
  }
  checking = true;
  lastCheckAt = nowISO();
  try {
    const list = await fetchTransactions();
    if (!list.length) {
      console.log("[CHECK] không có giao dịch");
      return;
    }
    if (firstRun) {
      for (const tx of list) addSeen(tx.refNo);
      saveState();
      firstRun = false;
      lastSuccessAt = nowISO();
      console.log(`[INIT] đã ghi nhớ ${list.length} giao dịch cũ, không gửi lại`);
      return;
    }
    const newTxs = list.filter((tx) => !hasSeen(tx.refNo));
    if (!newTxs.length) {
      lastSuccessAt = nowISO();
      console.log("[CHECK] không có giao dịch mới");
      return;
    }
    for (const tx of newTxs) addSeen(tx.refNo);
    saveState();
    console.log(`[CHECK] phát hiện ${newTxs.length} giao dịch mới`);
    await processNotifications(newTxs);
    lastSuccessAt = nowISO();
  } catch (err) {
    totalErrors++;
    console.log("[CHECK] error:", err.message);
  } finally {
    checking = false;
  }
}
function restartCheckLoop() {
  if (checkTimer) clearInterval(checkTimer);
  checkTimer = setInterval(check, config.checkIntervalMs);
  console.log(`[BOT] restart loop interval = ${config.checkIntervalMs}ms`);
}

function parseCookies(cookieHeader = "") {
  const out = {};
  cookieHeader.split(";").forEach((part) => {
    const idx = part.indexOf("=");
    if (idx > -1) {
      const k = part.slice(0, idx).trim();
      const v = part.slice(idx + 1).trim();
      out[k] = decodeURIComponent(v);
    }
  });
  return out;
}
function readBody(req) {
  return new Promise((resolve, reject) => {
    let data = "";
    req.on("data", (chunk) => {
      data += chunk;
      if (data.length > 1024 * 1024) {
        req.destroy();
        reject(new Error("Body too large"));
      }
    });
    req.on("end", () => resolve(data));
    req.on("error", reject);
  });
}
function isAuthed(req) {
  const cookies = parseCookies(req.headers.cookie || "");
  const sid = cookies.sid;
  if (!sid) return false;
  const exp = sessions.get(sid);
  if (!exp) return false;
  if (Date.now() > exp) {
    sessions.delete(sid);
    return false;
  }
  return true;
}
function issueSession(res) {
  const sid = crypto.randomBytes(24).toString("hex");
  sessions.set(sid, Date.now() + 7 * 24 * 60 * 60 * 1000);
  res.setHeader("Set-Cookie", `sid=${sid}; HttpOnly; Path=/; Max-Age=604800; SameSite=Lax`);
}
function destroySession(req, res) {
  const cookies = parseCookies(req.headers.cookie || "");
  if (cookies.sid) sessions.delete(cookies.sid);
  res.setHeader("Set-Cookie", "sid=; HttpOnly; Path=/; Max-Age=0; SameSite=Lax");
}
function redirect(res, location) {
  res.writeHead(302, { Location: location });
  res.end();
}
function htmlPage(title, body) {
  return `<!doctype html><html lang="vi"><head><meta charset="utf-8" /><meta name="viewport" content="width=device-width,initial-scale=1" /><title>${esc(title)}</title><style>
body{font-family:Arial,sans-serif;background:#0f1115;color:#eaeef5;margin:0;padding:20px}
.container{max-width:1100px;margin:0 auto}
.card{background:#171b22;border:1px solid #2c3340;border-radius:16px;padding:18px;margin-bottom:18px}
h1,h2,h3{margin:0 0 14px}
input,button,select{padding:12px;border-radius:10px;border:1px solid #323b4a;background:#0f1115;color:#fff}
input[type=text],input[type=password],input[type=number]{width:100%;box-sizing:border-box}
button{cursor:pointer;background:#2563eb;border:none}
button.red{background:#dc2626}
button.gray{background:#374151}
.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(240px,1fr));gap:12px}
table{width:100%;border-collapse:collapse}
td,th{padding:10px;border-bottom:1px solid #2c3340;text-align:left;vertical-align:top}
small{color:#9ca3af}
a{color:#93c5fd;text-decoration:none}
.badge{display:inline-block;padding:4px 10px;border-radius:999px;background:#1f2937}
.success{color:#86efac}
.warn{color:#fde68a}
.muted{color:#9ca3af}
form.inline{display:inline}
pre{white-space:pre-wrap;background:#0f1115;padding:12px;border-radius:12px;border:1px solid #2c3340}
</style></head><body><div class="container">${body}</div></body></html>`;
}
function loginPage(message = "") {
  return htmlPage("Login", `<div class="card" style="max-width:420px;margin:60px auto"><h1>Admin Panel</h1><p class="muted">Đăng nhập để quản lý API và tốc độ cron.</p>${message ? `<p class="warn">${esc(message)}</p>` : ""}<form method="POST" action="/login"><label>Mật khẩu admin</label><br/><br/><input type="password" name="password" placeholder="Nhập ADMIN_PASSWORD" /><br/><br/><button type="submit">Đăng nhập</button></form></div>`);
}
function dashboardPage(msg = "") {
  const active = getActiveApi();
  const rows = config.apis.map((api, idx) => `<tr><td>${idx + 1}</td><td>${esc(api.name)}</td><td><small>${esc(api.url)}</small></td><td>${api.enabled ? '<span class="success">Bật</span>' : '<span class="warn">Tắt</span>'}</td><td>${idx === config.activeApiIndex ? '<span class="badge">Đang dùng</span>' : ''}</td><td><form class="inline" method="POST" action="/api/select"><input type="hidden" name="index" value="${idx}" /><button type="submit">Chọn</button></form> <form class="inline" method="POST" action="/api/toggle"><input type="hidden" name="index" value="${idx}" /><button type="submit" class="gray">${api.enabled ? 'Tắt' : 'Bật'}</button></form> <form class="inline" method="POST" action="/api/delete" onsubmit="return confirm('Xoá API này?')"><input type="hidden" name="index" value="${idx}" /><button type="submit" class="red">Xoá</button></form></td></tr>`).join("");
  return htmlPage("Admin Panel", `<div class="card"><h1>MB Bot Admin Panel</h1><p class="muted">Quản lý API payment, cron và trạng thái bot.</p>${msg ? `<p class="success">${esc(msg)}</p>` : ""}<p><a href="/logout">Đăng xuất</a></p></div>
  <div class="grid">
    <div class="card"><h2>Trạng thái</h2><p>API hiện tại: <b>${esc(active?.name || "N/A")}</b></p><p>URL: <small>${esc(active?.url || "N/A")}</small></p><p>Check interval: <b>${esc(config.checkIntervalMs)} ms</b></p><p>Send delay: <b>${esc(config.sendDelayMs)} ms</b></p><p>Batch mode: <b>${config.batchMode ? "Bật" : "Tắt"}</b></p><p>Total sent: <b>${totalSent}</b></p><p>Total errors: <b>${totalErrors}</b></p><p>Last check: <small>${esc(lastCheckAt || "Chưa có")}</small></p><p>Last success: <small>${esc(lastSuccessAt || "Chưa có")}</small></p></div>
    <div class="card"><h2>Cron / tốc độ</h2><form method="POST" action="/settings"><label>Check interval (ms)</label><br/><br/><input type="number" name="checkIntervalMs" min="1000" max="3600000" value="${esc(config.checkIntervalMs)}" /><br/><br/><label>Send delay (ms)</label><br/><br/><input type="number" name="sendDelayMs" min="0" max="60000" value="${esc(config.sendDelayMs)}" /><br/><br/><label>Retry gửi Telegram</label><br/><br/><input type="number" name="telegramRetry" min="1" max="20" value="${esc(config.telegramRetry)}" /><br/><br/><label>Retry delay (ms)</label><br/><br/><input type="number" name="telegramRetryDelayMs" min="100" max="60000" value="${esc(config.telegramRetryDelayMs)}" /><br/><br/><label>Max seen refs</label><br/><br/><input type="number" name="maxSeen" min="100" max="100000" value="${esc(config.maxSeen)}" /><br/><br/><label><input type="checkbox" name="batchMode" ${config.batchMode ? "checked" : ""} /> Bật batch mode</label><br/><br/><button type="submit">Lưu cài đặt</button></form></div>
  </div>
  <div class="card"><h2>Thêm API mới</h2><form method="POST" action="/api/add"><div class="grid"><div><label>Tên API</label><br/><br/><input type="text" name="name" placeholder="Ví dụ: API MB phụ" /></div><div><label>Link API</label><br/><br/><input type="text" name="url" placeholder="https://..." /></div></div><br/><button type="submit">Thêm API</button></form></div>
  <div class="card"><h2>Danh sách API</h2><table><thead><tr><th>#</th><th>Tên</th><th>URL</th><th>Trạng thái</th><th>Active</th><th>Hành động</th></tr></thead><tbody>${rows}</tbody></table></div>`);
}
async function parseForm(req) {
  const raw = await readBody(req);
  return Object.fromEntries(new URLSearchParams(raw));
}

const server = http.createServer(async (req, res) => {
  try {
    const parsedUrl = new URL(req.url, `http://${req.headers.host || "localhost"}`);
    const pathname = parsedUrl.pathname;
    if (req.method === "GET" && pathname === "/health") {
      const active = getActiveApi();
      const body = { ok: true, service: "mb-telegram-bot", time: nowISO(), lastCheckAt, lastSuccessAt, seen: seenList.length, totalSent, totalErrors, intervalMs: config.checkIntervalMs, activeApi: active };
      res.writeHead(200, { "Content-Type": "application/json; charset=utf-8" });
      res.end(JSON.stringify(body, null, 2));
      return;
    }
    if (req.method === "GET" && pathname === "/") {
      if (!isAuthed(req)) {
        res.writeHead(200, { "Content-Type": "text/html; charset=utf-8" });
        res.end(loginPage());
        return;
      }
      res.writeHead(200, { "Content-Type": "text/html; charset=utf-8" });
      res.end(dashboardPage(parsedUrl.searchParams.get("msg") || ""));
      return;
    }
    if (req.method === "POST" && pathname === "/login") {
      const form = await parseForm(req);
      if (String(form.password || "") !== ADMIN_PASSWORD) {
        res.writeHead(200, { "Content-Type": "text/html; charset=utf-8" });
        res.end(loginPage("Sai mật khẩu"));
        return;
      }
      issueSession(res);
      redirect(res, "/?msg=Đăng nhập thành công");
      return;
    }
    if (req.method === "GET" && pathname === "/logout") {
      destroySession(req, res);
      redirect(res, "/");
      return;
    }
    if (!isAuthed(req)) {
      redirect(res, "/");
      return;
    }
    if (req.method === "POST" && pathname === "/settings") {
      const form = await parseForm(req);
      config.checkIntervalMs = safeNumber(form.checkIntervalMs, config.checkIntervalMs, 1000, 3600000);
      config.sendDelayMs = safeNumber(form.sendDelayMs, config.sendDelayMs, 0, 60000);
      config.telegramRetry = safeNumber(form.telegramRetry, config.telegramRetry, 1, 20);
      config.telegramRetryDelayMs = safeNumber(form.telegramRetryDelayMs, config.telegramRetryDelayMs, 100, 60000);
      config.maxSeen = safeNumber(form.maxSeen, config.maxSeen, 100, 100000);
      config.batchMode = form.batchMode === "on";
      saveConfig();
      restartCheckLoop();
      redirect(res, "/?msg=Đã lưu cài đặt");
      return;
    }
    if (req.method === "POST" && pathname === "/api/add") {
      const form = await parseForm(req);
      const name = String(form.name || "").trim() || `API ${config.apis.length + 1}`;
      const url = String(form.url || "").trim();
      if (!url) {
        redirect(res, "/?msg=Thiếu URL API");
        return;
      }
      config.apis.push({ name, url, enabled: true });
      saveConfig();
      redirect(res, "/?msg=Đã thêm API");
      return;
    }
    if (req.method === "POST" && pathname === "/api/delete") {
      const form = await parseForm(req);
      const index = safeNumber(form.index, -1, -1, config.apis.length - 1);
      if (index < 0 || config.apis.length <= 1) {
        redirect(res, "/?msg=Không thể xoá API này");
        return;
      }
      config.apis.splice(index, 1);
      if (config.activeApiIndex >= config.apis.length) config.activeApiIndex = config.apis.length - 1;
      saveConfig();
      redirect(res, "/?msg=Đã xoá API");
      return;
    }
    if (req.method === "POST" && pathname === "/api/select") {
      const form = await parseForm(req);
      const index = safeNumber(form.index, -1, -1, config.apis.length - 1);
      if (index < 0) {
        redirect(res, "/?msg=API không hợp lệ");
        return;
      }
      config.activeApiIndex = index;
      saveConfig();
      redirect(res, "/?msg=Đã đổi API đang dùng");
      return;
    }
    if (req.method === "POST" && pathname === "/api/toggle") {
      const form = await parseForm(req);
      const index = safeNumber(form.index, -1, -1, config.apis.length - 1);
      if (index < 0) {
        redirect(res, "/?msg=API không hợp lệ");
        return;
      }
      config.apis[index].enabled = !config.apis[index].enabled;
      if (!config.apis[config.activeApiIndex]?.enabled) {
        const nextEnabled = config.apis.findIndex(x => x.enabled);
        if (nextEnabled !== -1) config.activeApiIndex = nextEnabled;
      }
      saveConfig();
      redirect(res, "/?msg=Đã đổi trạng thái API");
      return;
    }
    res.writeHead(404, { "Content-Type": "text/plain; charset=utf-8" });
    res.end("Not found");
  } catch (err) {
    totalErrors++;
    res.writeHead(500, { "Content-Type": "text/plain; charset=utf-8" });
    res.end("Server error: " + err.message);
  }
});

function validateConfig() {
  if (!BOT_TOKEN || BOT_TOKEN === "YOUR_BOT_TOKEN") {
    console.log("[FATAL] thiếu BOT_TOKEN");
    process.exit(1);
  }
  if (!CHAT_ID || CHAT_ID === "-1000000000000") {
    console.log("[FATAL] thiếu CHAT_ID");
    process.exit(1);
  }
}
async function start() {
  validateConfig();
  loadConfig();
  loadState();
  server.listen(PORT, () => {
    console.log(`[HTTP] listening on port ${PORT}`);
  });
  console.log("[BOT] started");
  console.log("[BOT] CHAT_ID =", CHAT_ID);
  console.log("[BOT] ACTIVE_API =", getActiveApi()?.url);
  console.log("[BOT] CHECK_INTERVAL_MS =", config.checkIntervalMs);
  console.log("[BOT] SEND_DELAY_MS =", config.sendDelayMs);
  console.log("[BOT] TELEGRAM_RETRY =", config.telegramRetry);
  console.log("[BOT] BATCH_MODE =", config.batchMode);
  await check();
  restartCheckLoop();
}
start().catch((err) => {
  console.log("[FATAL]", err.message);
  process.exit(1);
});
async function shutdown(signal) {
  try {
    console.log(`[EXIT] ${signal} received, saving state...`);
    saveConfig();
    saveState();
    server.close(() => {
      console.log("[EXIT] http server closed");
      process.exit(0);
    });
    setTimeout(() => {
      console.log("[EXIT] force exit");
      process.exit(0);
    }, 5000);
  } catch (err) {
    console.log("[EXIT] error:", err.message);
    process.exit(1);
  }
}
process.on("SIGINT", () => shutdown("SIGINT"));
process.on("SIGTERM", () => shutdown("SIGTERM"));
process.on("uncaughtException", (err) => {
  totalErrors++;
  console.log("[uncaughtException]", err.message);
});
process.on("unhandledRejection", (reason) => {
  totalErrors++;
  console.log("[unhandledRejection]", String(reason));
});
