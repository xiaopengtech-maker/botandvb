# MB Telegram Bot Admin Panel (Ubuntu VPS)

Bot báo giao dịch mới từ API MB Bank về Telegram, có admin panel web để:

- thêm / xoá / chọn API payment
- chỉnh tốc độ cron `checkIntervalMs`
- chỉnh `sendDelayMs`, retry, batch mode
- xem trạng thái bot

## Cài trên Ubuntu VPS

```bash
git clone YOUR_GITHUB_REPO
cd YOUR_REPO
bash run.sh
```

## Export biến môi trường

```bash
export BOT_TOKEN="TOKEN_MOI_CUA_BAN"
export CHAT_ID="-1003910243518"
export ADMIN_PASSWORD="123456"
export PORT="3000"
```

## Chạy bot

```bash
node index.js
```

## Chạy nền bằng PM2

```bash
pm2 start index.js --name mbbot --update-env
pm2 save
pm2 startup
```

## Admin panel

Mở:

```text
http://IP_VPS:3000/
```

Đăng nhập bằng `ADMIN_PASSWORD`.

## Health

```text
http://IP_VPS:3000/health
```
