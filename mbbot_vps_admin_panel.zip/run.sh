#!/bin/bash
set -e
echo "[1/4] sudo apt update"
sudo apt update
echo "[2/4] install nodejs + npm"
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt-get install -y nodejs
echo "[3/4] install pm2"
sudo npm install -g pm2
echo "[4/4] npm install"
npm install
echo "Done."
echo 'Export BOT_TOKEN, CHAT_ID, ADMIN_PASSWORD, PORT before start.'
